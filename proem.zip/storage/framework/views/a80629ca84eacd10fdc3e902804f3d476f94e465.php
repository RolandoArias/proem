<div class="header_info">
    <div class="row">
        <div class="col-md-12 text-center">
            <ul class="datos_contacto">
                <li class="hidden-xs hidden-sm"><a data-popup="crear_cuenta"><i class="fa fa-pencil-square-o "></i> Crear cuenta</a></li>
                <li class="hidden-xs hidden-sm"><a data-popup="login"><i class="fa fa-sign-in"></i> Login</a></li>
                <li class="hidden-xs hidden-sm"><a href="https://www.facebook.com/prominmx/" target="_blank"><i class="fa fa-facebook"></i></a></li>
                <li class="hidden-xs hidden-sm"><a href="https://www.instagram.com/promin_mexico/" target="_blank"><i class="fa fa-instagram"></i></a></li>
                <li class="hidden-xs hidden-sm"><a href="https://www.youtube.com/channel/UCh-frRoUXQciPpdv2bJmZ_w/videos" target="_blank"><i class="fa fa-youtube"></i></a></li>
                <li class="hidden-xs hidden-sm"><a href="https://www.linkedin.com/in/promin-m%C3%A9xico-96741213a/" target="_blank"><i class="fa fa-linkedin"></i></a></li>
                <li class="hidden-xs hidden-sm"><a href="mailto:contacto@promin.mx" class="a-email"><i class="fa fa-envelope"></i> contacto@promin.mx</a></li>
                <li class="hidden-xs hidden-sm"><a href="tel:+52-55-2643-0892" class="tel_top"><i class="fa fa-phone"></i> 2643-0892</a></li>
                <li class="hidden-xs hidden-sm"><a href="tel:+52-55-7155-5874" class="tel_top"><i class="fa fa-phone"></i> 7155-5874</a></li>
                <li><?php echo $__env->make('includes.carrito', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?></li>
            </ul>
        </div>
    </div>
</div>
<div class="container borde_bottom hidden-xs hidden-sm">
    <div class="row">
        <div class="col-md-12 text-center">
             <a href="index.php"><img src="/assets/images/proveedora-equipos-mineros-promin-logo.png" alt="Proveedora de Equipos Mineros"></a>
         </div>    
    </div>
</div>