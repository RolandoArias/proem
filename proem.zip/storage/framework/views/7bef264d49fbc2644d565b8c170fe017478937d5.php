<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1">
    <title>Proveedora de Equipos Mineros - PROMIN - Mexico / USA</title>
    <meta name="keywords" content="mineria, construccion, agricultura, scoop tram, maquinaria para mineria, maquinaria para construccion, maquinaria para agricultura, maquinaria pesada, proveedora de equipos mineros">
    <meta name="description" content="Asesores en Maquinaria para Mineria, Construcción y Agricultura.">

    <link rel="shortcut icon" href="<?php echo e(url('favicon.ico')); ?>">
    
    <link href="<?php echo e(url('assets/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(url('assets/css/style.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(url('assets/css/stilos.css')); ?>" rel="stylesheet">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
</head>
<body>

    

<!-- Preloader -->
<?php echo $__env->make('includes.area_preloader', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


<!-- Chat -->
<?php echo $__env->make('includes.area_chat', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!-- Top Datos -->
<?php if(Auth::guest()): ?>
    <?php echo $__env->make('includes.area_top_dato', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php else: ?>
    <?php echo $__env->make("includes.area_top_datos_login", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php endif; ?>
<!-- WRAPPER -->
<div class="wrapper">
    
    <!-- MENU -->
    <?php echo $__env->make('includes.inicio_menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php if($carousel): ?>
    <!-- CARRUSEL -->
    <?php echo $__env->make('includes.inicio_carrusel', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php endif; ?>
    
    <!-- CONTENT -->
    <div class="content">
        
        <!-- CONTENIDO -->
        <?php echo $__env->yieldContent('content'); ?>

        <!-- NEWSLETTER -->
        <?php echo $__env->make('includes.area_newsletter2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        
    </div>
    <!-- /.content -->

</div>
<!-- /.wrapper -->



<!-- FOOTER -->
<?php echo $__env->make('includes.area_footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!-- LOGIN -->
<?php echo $__env->make('includes.area_login', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!-- Crear Cuenta -->
<?php echo $__env->make('includes.area_crear_cuenta', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!-- ScrollTop Button -->
<?php echo $__env->make('includes.area_boton_scroll', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>



<script src="<?php echo e(url('assets/js/jquery-2.1.1.min.js')); ?>"></script>
<script src="<?php echo e(url('assets/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(url('assets/js/jquery.plugins.min.js')); ?>"></script>
<script src="<?php echo e(url('assets/js/custom.min.js')); ?>"></script>
<script src="<?php echo e(url('assets/js/promin.js')); ?>"></script>
<script>
    var player = new MediaElementPlayer('#player1');
</script>

</body>

</html>