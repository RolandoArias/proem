@extends('layouts.main')
@section('content')
  @include('includes.inicio_contenido')   
@stop