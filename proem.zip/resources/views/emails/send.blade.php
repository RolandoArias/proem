<table style="margin-top: 0px; margin-bottom: 6px; background-color: #ffffff;" id="textEdit" border="0" cellpadding="5" cellspacing="0" width="100%">
  <tbody>
    <tr>
      <td class="MainText" align="left" data-gcf-font-size="10pt">
        <table style="display: inline-table;" border="0" width="810" cellspacing="0" cellpadding="0">
          <tbody>
            <tr>
              <td><a shape="rect" href="http://www.parkavenue.com.sv/"><img  width="810" src="http://sitioswebelsalvador.net/boletines/park/07-03-2017/BOLETINPARK.png"></a></td>
            </tr>
          </tbody>
        </table>
      </td>
    </tr>
  </tbody>
</table>