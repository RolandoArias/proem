<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, minimum-scale=1.0, maximum-scale=1.0">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Promo Cereales Golden Foods </title>
     
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="shortcut icon" href="">

    <meta property="og:url" content="">
    <meta property="og:title" content="">
    <meta property="og:description" content="">
    <meta property="og:image" content="">
    <meta property="og:site_name" content="">
    <meta property="og:image:type" content="image/png">
    <link rel="stylesheet" href="{{ asset('assets_pro/css/style.css') }}">
    <link rel="icon" type="image/png" href="/assets_pro/img/favicon.png" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel="stylesheet" href="{{ asset('assets_pro/css/animate.css') }}">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
     
    {!! HTML::style('/assets/css/validetta.min.css') !!}
        <style>
            html, body {
                height: 100%;
            }

            body {
                margin: 0;
                padding: 0;
                width: 100%;
                color: #B0BEC5;
                display: table;
                font-weight: 100;
                font-family: 'Lato';
                overflow: hidden;
            }

            .container {
                text-align: center;
                display: table-cell;
                vertical-align: middle;
            }

            .content {
                text-align: center;
                display: inline-block;
            }

            .title {
                font-size: 72px;
                margin-bottom: 40px;
            }
        </style>
    </head>
    <body>
    <div class="title" style="
        text-align: center;
    display: block;
    width: 100%;
    position: absolute;
    height: 100px;
    margin: 0;
    background: white;
">Lo sentimos, esta página  no existe. <br> <a class="btn btn-md btn-success" href="/">Ir a Inicio</a></div><div class="container-fluid home-section nopad">    
        
     </div>
    

</body>
</html>
