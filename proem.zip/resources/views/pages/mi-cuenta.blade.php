@extends('layouts.main')

@section('content')     
    @include('includes.mi_cuenta_contenido')
@stop