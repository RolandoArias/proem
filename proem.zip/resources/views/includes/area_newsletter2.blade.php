<div class="bg_newsletter" style="padding: 45px 0;">
    <div class="row text-center">
        <div class="col-md-10 col-md-offset-1">
            <h2 class="tipo_blanca">Newsletter</h2>
            <p class="tipo_blanca">Recibe las mejores promociones de maquinaria.</p>
        </div>
    </div>
    
    <div class="row">
        <div class="col-md-3 col-md-offset-2">
              <div class="form-group">
                <input type="email" class="form-control" id="email" placeholder="Email">
              </div>
        </div>

        <div class="col-md-3" style="margin-bottom: 10px;">
            <select class="form-control" style="padding: 35px 15px;"> <!---->
                    <option value="">Servicio</option>        
                    <option value="">Minería</option>
                    <option value="">Construcción</option>
                    <option value="">Agricultura</option>
                    <option value="">Otros</option>
                </select>
        </div>

        <div class="col-md-3 skin-yellow">
            <button type="submit" class="btn btn-default"><i class="fa fa-check"></i> Suscribirme</button>
              <br>
              <div class="checkbox">
                <label><input type="checkbox" checked=""> <span class="tipo_chk_aviso">Acepto Aviso de Privacidad<span></label>
              </div>
            </form>
        </div>

        
    </div>
</div>