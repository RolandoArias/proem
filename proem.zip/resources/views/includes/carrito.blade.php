<div class="hcart">
    <a href="pago-seguro.php" class="btn_carrito"><i class="fa fa-shopping-cart carrito"></i> 3 items - $23,000.00</a>
    <div class="dropdown">
        <nav>
        <ul class="hcart-list">
            <li>
                <a href="producto.php" class="fig pull-left"><img src="/assets/images/bomba_contreto_kcp_2_thumb.jpg" alt=""></a>
                <div class="block">
                    <a href="producto.php">1KCP-545 Bomba de Concreto</a>
                    <div class="cost"><input type="number" class="input_cant" value="1"> $2,200.00 <div class="container_eliminar pull-right"><a href=""><i class="fa fa-remove tipo_roja"></i></a></div></div>
                </div>
            </li>
            <li>
                <a href="producto.php" class="fig pull-left"><img src="/assets/images/cargador_john_deere_thumb.jpg" alt=""></a>
                <div class="block">
                    <a href="producto.php">1JD-3KF Cargador</a>
                    <div class="cost"><input type="number" class="input_cant" value="2"> $18,000.00 <div class="container_eliminar pull-right"><a href=""><i class="fa fa-remove tipo_roja"></i></a></div></div>
                </div>
            </li>
            <li>
                <a href="producto.php" class="fig pull-left"><img src="/assets/images/minicargador-caterpillar-216b_thumb.jpg" alt=""></a>
                <div class="block">
                    <a href="producto.php">1CA-216B Mini Cargador</a>
                    <div class="cost"><input type="number" class="input_cant" value="1"> $2,800.00 <div class="container_eliminar pull-right"><a href=""><i class="fa fa-remove tipo_roja"></i></a></div></div>
                </div>
            </li>
        </ul>
        </nav>
        <div class="hcart-total">
            <a href="pago-seguro.php" class="btn btn-default btn_checkout"><i class="fa fa-check"></i> Checkout</a>
            <div class="total">Total: <ins>$23,000.00</ins></div>
        </div>
    </div>
</div>