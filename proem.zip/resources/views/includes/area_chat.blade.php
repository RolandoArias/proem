<div id="chat_div">
    <a href=""><i class="fa fa-comments"></i> Chat en Línea</a>
</div>